package com.baehw1107.sharepark2.model;

/**
 * Created by baehw_000 on 2017-05-18.
 */

    public class Response {

        private String message;
        private String token;

        public String getMessage() {
            return message;
        }

        public String getToken() {
            return token;
        }
    }