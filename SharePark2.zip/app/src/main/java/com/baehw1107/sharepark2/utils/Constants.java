package com.baehw1107.sharepark2.utils;

/**
 * Created by baehw_000 on 2017-05-18.
 */

public class Constants {
    public static final String BASE_URL = "http://10.0.2.2:8080/api/v1/";
    public static final String TOKEN = "token";
    public static final String EMAIL = "email";
}
