package com.baehw1107.share_park5.utils;

/**
 * Created by baehw_000 on 2017-06-04.
 */

public class Constants {

    public static final String BASE_URL = "http://ec2-52-79-181-244.ap-northeast-2.compute.amazonaws.com:8080";
    public static final String TOKEN = "token";
    public static final String EMAIL = "email";
}
