package com.baehw1107.share_park5.model;

/**
 * Created by baehw_000 on 2017-06-04.
 */

public class Response {

    private String message;
    private String token;

    public String getMessage() {
        return message;
    }

    public String getToken() {
        return token;
    }
}
